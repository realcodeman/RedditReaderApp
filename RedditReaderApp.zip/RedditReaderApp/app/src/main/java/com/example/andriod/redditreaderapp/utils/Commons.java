package com.example.andriod.redditreaderapp.utils;

public class Commons {
    private String name;
    public static final String BASEURL = "https://www.reddit.com/r/";
}
